package com.produce.model;

public enum Gender {
    F,M
}
