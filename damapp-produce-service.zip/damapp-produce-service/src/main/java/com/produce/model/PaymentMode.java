package com.produce.model;

public enum PaymentMode {
    ONLINE,OFFLINE
}
