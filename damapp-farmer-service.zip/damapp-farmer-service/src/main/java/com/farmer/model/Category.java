package com.farmer.model;/*
 *@created 22-12-2021/12/2021 - 04:04 PM
 *@project IntelliJ IDEA
 *@author  ArunSaiSurapaneni
 */

public enum Category {
    VEGETABLESELLER,FRUITSELLER,CLOTHING,SUPERMARKET,HOTELS,HOSTELS
}
