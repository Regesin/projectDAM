package com.farmer.model;/*
 *@created 22-12-2021/12/2021 - 03:43 PM
 *@project IntelliJ IDEA
 *@author  ArunSaiSurapaneni
 */

public enum Type {
    HYBRID, NORMAl
}
