package com.farmer.model;/*
 *@created 22-12-2021/12/2021 - 03:40 PM
 *@project IntelliJ IDEA
 *@author  ArunSaiSurapaneni
 */

public enum Fertilizer {
    ORGANIC,INORGANIC;
}
