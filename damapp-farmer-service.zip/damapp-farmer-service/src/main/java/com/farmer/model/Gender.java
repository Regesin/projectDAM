package com.farmer.model;

public enum Gender {
    F,M
}
