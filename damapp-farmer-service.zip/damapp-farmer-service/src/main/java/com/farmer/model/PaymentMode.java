package com.farmer.model;

public enum PaymentMode {
    ONLINE,OFFLINE
}
