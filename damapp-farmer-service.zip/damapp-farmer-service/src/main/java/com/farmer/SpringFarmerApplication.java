package com.farmer;

import com.farmer.model.*;
import com.farmer.service.IFarmDetailsService;
import com.farmer.service.IFarmerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
@EnableEurekaClient
public class SpringFarmerApplication implements CommandLineRunner{

    public static void main(String[] args) {
        SpringApplication.run(SpringFarmerApplication.class, args);
    }
     IFarmerService farmerService;

    @Autowired
    public void setFarmerService(IFarmerService farmerService) {
        this.farmerService = farmerService;
    }

    IFarmDetailsService farmDetailsService;
    @Autowired
    public void setFarmDetailsService(IFarmDetailsService farmDetailsService) {
        this.farmDetailsService = farmDetailsService;
    }

    @Bean
    @LoadBalanced
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }

    @Override
    public void run(String... args) throws Exception {


        Produce produce= farmDetailsService.getByProduceId(1);
        Produce produce1=farmDetailsService.getByProduceId(2);
        System.out.println(produce);
        System.out.println("Hi");
        Set<Produce> produceSet = new HashSet<>(Arrays.asList(produce,produce1));



        FarmDetails farm1 = new FarmDetails(3.5, "black", "Kurnool", 507144, produceSet);
//        FarmDetails farm2 = new FarmDetails(11.4, "red", "Anantapur", 515001, produceSet2);
//        FarmDetails farm3 = new FarmDetails(29.4, "clay", "Kadapa", 516432, produceSet3);
//        FarmDetails farm4 = new FarmDetails(52, "black", "Khammam", 507154, produceSet4);
//



        Set<FarmDetails> farmDetails1 = new HashSet<>(Arrays.asList(farm1));
//        Set<FarmDetails> farmDetails2 = new HashSet<>(Arrays.asList(farm2));
//        Set<FarmDetails> farmDetails3 = new HashSet<>(Arrays.asList(farm3));
//        Set<FarmDetails> farmDetails4 = new HashSet<>(Arrays.asList(farm4));
//
//        //------------------



        Farmer farmer1 = new Farmer("Sreeramulu", 40, Gender.M, "8639835412", farmDetails1);
//        Farmer farmer2 = new Farmer("Divya", 25, Gender.F, "9848754578", farmDetails2);
//        Farmer farmer3 = new Farmer("Arun",21 , Gender.M, "7515452136", farmDetails3);
//        Farmer farmer4 = new Farmer("Raj", 28, Gender.M, "8745129654", farmDetails4);


      farmerService.addFarmer(farmer1);
//        farmerService.addFarmer(farmer2);
//        farmerService.addFarmer(farmer3);
//        farmerService.addFarmer(farmer4);


    }
}
